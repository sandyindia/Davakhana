package com.techsoft.davakhana.adapters;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.techsoft.davakhana.fragments.LoginPagerFragment;

/**
 * Created by root on 23/8/17.
 */

public class LoginPagerAdapter extends FragmentPagerAdapter {

    @Override
    public Fragment getItem(int position) {
        return LoginPagerFragment.newInstance(position);
    }

    @Override
    public int getCount() {
        return 4;
    }

    public LoginPagerAdapter(FragmentManager fm) {
        super(fm);
    }
}