package com.techsoft.davakhana.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.LayerDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.MediaStore;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.techsoft.davakhana.R;
import com.techsoft.davakhana.utils.Constant;
import com.techsoft.davakhana.utils.ImageRelated;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import okhttp3.RequestBody;


public class BaseFragment extends Fragment {

    /* replace a fragment without adding it to back stack*/
    protected void replaceFragment(FragmentActivity activity, int container, Fragment fragment){
        activity.getSupportFragmentManager().beginTransaction().replace(container, fragment).commit();
    }

    /* replace a fragment without adding it to back stack*/
    protected void addFragmentToStack(FragmentActivity activity, int container, String[] tags, Fragment fragment){
        activity.getSupportFragmentManager()
                .beginTransaction()
                .addToBackStack(tags[0])
                .add(container, fragment, tags[1])
                .commit();
    }

    /* replace a fragment without adding it to back stack*/
    protected void replaceFragmentToStack(FragmentActivity activity, int container, String[] tags, Fragment fragment){
        activity.getSupportFragmentManager()
                .beginTransaction()
                .addToBackStack(tags[0])
                .replace(container, fragment, tags[1])
                .commit();
    }

    /** starts a new activity class
     * @param activity
     * @param type*/
    protected void startAnActivity(FragmentActivity activity, Class<?> type) {
        activity.finish();
        startActivity(new Intent(activity, type));
    }

    /** pass a
     * @param message to display it in a toast
     * @param context */
    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    /** pop fragment from stack
     * @param activity
     * */
    protected void popUpFromBackStack(FragmentActivity activity) {
        activity.getSupportFragmentManager().popBackStack();
    }

    /* check network connectivity */
    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        boolean connected = netInfo != null && netInfo.isConnectedOrConnecting();
        if (!connected)
            showToast(context, Constant.NO_INTERNET_CONNECTION);
        return connected;
    }

    /** animate a view */
    protected Animation animate(FragmentActivity activity, int anim){
        Animation animation = AnimationUtils.loadAnimation(activity, anim);
        animation.setInterpolator((new AccelerateDecelerateInterpolator()));
        animation.setFillAfter(true);
        return animation;
    }

    /** open an image chooser */
    protected void openPhotoChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Image"), ImageRelated.REQUEST_PHOTO);
    }

    protected void selectMultipleIntent(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Pictures"), ImageRelated.PICK_IMAGE_MULTIPLE);
    }

    protected Toolbar setToolbar(View v, int res, final boolean backButton) {
        Toolbar toolbar = (Toolbar) v.findViewById(R.id.nwc_toolbar);
        TextView tvTitle = (TextView) toolbar.findViewById(R.id.nwc_toolbar_tv);
        tvTitle.setText(getString(res));
        ImageView imageView = (ImageView) toolbar.findViewById(R.id.nwc_toolbar_ic_drawer);
        if (backButton) {
            imageView.setImageResource(R.drawable.ic_launcher_foreground);
           // lockDrawer();
        }
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (backButton) {
                    hideSoftKeyboard();
                   // unlockDrawer();
                    popUpFromBackStack(getActivity());
                } //else openDrawer();
            }
        });
        return toolbar;
    }

    /* lock the navigation drawer */
  /*  public void lockDrawer() {
        DrawerLayout drawer = (DrawerLayout) getActivity().findViewById(R.id.drawer_layout);
        drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
    }

    *//* unlock the navigation drawer *//*
    public void unlockDrawer() {
        DrawerLayout drawer = (DrawerLayout) getActivity().findViewById(R.id.drawer_layout);
        drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
    }*/

   /* public void openDrawer() {
        ((DrawerLayout) getActivity().findViewById(R.id.drawer_layout)).openDrawer(GravityCompat.END);
    }*/
    public void hideSoftKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
    }

    protected Typeface font(FragmentActivity activity, String font) {
        return Typeface.createFromAsset(activity.getAssets(),  "fonts/" + font);
    }

    // format date time string
    public static String formatDateTime(String format, String dateTime) {
        try {
            dateTime = new SimpleDateFormat(format, Locale.US)
                    .format(new SimpleDateFormat(Constant.DATE_TIME_US, Locale.US).parse(dateTime));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateTime;
    }

    protected RequestBody createPartFromString(String descriptionString) {
        return RequestBody.create(okhttp3.MultipartBody.FORM, descriptionString);
    }

    protected void initEditText(EditText editText, String mobileOrEmail) {
        editText.setText(mobileOrEmail);
        editText.setEnabled(false);
        editText.setFocusable(false);
    }

    /* change bottom navigation visibility */
   /* public void changeBottomNavVisibility(int visitbility) {
        BottomNavigationView bnv = (BottomNavigationView) getActivity().findViewById(R.id.nav_bottom);
        bnv.setVisibility(visitbility);
    }*/

    public static JsonObject fromString(String jsonStr){
        JsonParser parser = new JsonParser();
        return parser.parse(jsonStr).getAsJsonObject();
    }

    protected JsonArray fromArrayString(String jsonStr){
        JsonParser parser = new JsonParser();
        return parser.parse(jsonStr).getAsJsonArray();
    }

    protected ProgressBar getProgressBar(View view){
        ProgressBar progressBar = (ProgressBar) view.findViewById(R.id.progress_bar);
        progressBar.setVisibility(ProgressBar.VISIBLE);
        return progressBar;
    }

   /* protected SwipeRefreshLayout getSwipeRefreshLayout(View view){
        SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setColorSchemeResources(
                android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);
        return swipeRefreshLayout;
    }*/

    public static void layerRatingPurple(Context context, RatingBar ratingBar){
        LayerDrawable stars = (LayerDrawable) ratingBar.getProgressDrawable();
        stars.getDrawable(2).setColorFilter(ContextCompat.getColor(context, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
        stars.getDrawable(0).setColorFilter(ContextCompat.getColor(context, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
    }

    protected boolean notGranted(Context context, String permission){
        return ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED;
        //return(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }
}
