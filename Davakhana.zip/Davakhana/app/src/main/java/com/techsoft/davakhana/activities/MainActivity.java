package com.techsoft.davakhana.activities;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Handler;

import com.techsoft.davakhana.Davakhana;
import com.techsoft.davakhana.R;
import com.techsoft.davakhana.adapters.NavViewRecyclerViewAdapter;
import com.techsoft.davakhana.fragments.BaseFragment;
import com.techsoft.davakhana.interfaces.OnFragmentCreated;
import com.techsoft.davakhana.interfaces.OnNavItemSelected;
import com.techsoft.davakhana.models.Menu;
import com.techsoft.davakhana.utils.Constant;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity implements OnNavItemSelected, OnFragmentCreated {

    private NavViewRecyclerViewAdapter adapter;
    public static String CURRENT_TAG = "HomeFragment.TAG";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getIntent().getExtras() != null) {
            Davakhana.instance().dsp().clear();
            startAnActivity(this, GuestActivity.class);
        }

       /* NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        RecyclerView recyclerView = (RecyclerView) navigationView.findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        DividerItemDecoration mDividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                layoutManager.getOrientation());
        recyclerView.addItemDecoration(mDividerItemDecoration);
        adapter = new NavViewRecyclerViewAdapter(this, menus(), this);
        recyclerView.setAdapter(adapter);*/

      //  addFragment(Constant.CONTAINER_MAIN, new HomeFragment(), null);
    }

    @Override
    public void navItemSelected(Menu data) {
        Fragment fragment = null;
        switch (data.getTitle()) {//Check to see which item was being clicked and perform appropriate action

            case "OPD":
                //CURRENT_TAG = OPD.TAG;
                if (BaseFragment.isOnline(this))
                   // fragment = new HomeFragment();
                break;

            case "IPD":
                //CURRENT_TAG = IPD.TAG;
                if (BaseFragment.isOnline(this))
                    //fragment = new BookingsFragment();
                break;

            case "Emergency":
               // CURRENT_TAG = Emergency.TAG;
                if (BaseFragment.isOnline(this))
                    //fragment = new BookingsFragment();
                break;

            default:
                break;
        }
        if (fragment != null)
            replaceFragment(fragment);
    }

    private List<Menu> menus(){
        List<Menu> menus = new ArrayList<>();
        menus.add(menu("Dashboard", R.drawable.ic_menu_dashboard));
        menus.add(menu("Bookings", R.drawable.ic_menu_booking));
        menus.add(menu("Invoices", R.drawable.ic_menu_invoice));
        menus.add(menu("Chat", R.drawable.ic_menu_chat));
        menus.add(menu("Offers", R.drawable.ic_menu_offer));
        menus.add(menu("Blog", R.drawable.ic_menu_blog));
        menus.add(menu("Reviews", R.drawable.ic_menu_review));
        menus.add(menu("Tickets", R.drawable.ic_menu_ticket));
        menus.add(menu("Settings", R.drawable.ic_menu_setting));
        menus.add(menu("Help", R.drawable.ic_menu_help));
        menus.add(menu("Logout", R.drawable.ic_menu_logout));
        return menus;
    }

    private Menu menu(String title, int icon){
        Menu menu = new Menu();
        menu.setTitle(title);
        menu.setIcon(icon);
        return menu;
    }
    public void replaceFragment(final Fragment fragment) {
        Runnable mPendingRunnable = new Runnable() {
            @Override
            public void run() {
                // update the main content by replacing fragments
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.setCustomAnimations(android.R.anim.fade_in,
                        android.R.anim.fade_out);
                fragmentTransaction.replace(Constant.CONTAINER_MAIN, fragment, CURRENT_TAG);
                fragmentTransaction.commitAllowingStateLoss();
            }
        };
        // If mPendingRunnable is not null, then add to the message queue
        new Handler().post(mPendingRunnable);
        //Closing drawer on item click
        ((DrawerLayout) findViewById(R.id.drawer_layout)).closeDrawers();
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.END)) {
            drawer.closeDrawers();
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onFragmentCreated(String data) {
        adapter.notifyDataSetChanged();
    }
}
