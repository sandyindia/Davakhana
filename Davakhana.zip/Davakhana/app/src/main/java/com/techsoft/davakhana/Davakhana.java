package com.techsoft.davakhana;

import android.app.Application;

//import com.crashlytics.android.Crashlytics;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.techsoft.davakhana.interfaces.ApiService;
import com.techsoft.davakhana.utils.Constant;
import com.techsoft.davakhana.utils.DavakhanaSharedPreferences;

//import io.fabric.sdk.android.Fabric;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Davakhana extends Application {

    private static Davakhana davakhana;
    private DavakhanaSharedPreferences dsp;

    @Override
    public void onCreate() {
        super.onCreate();
        davakhana = this;
        // Fabric.with(this, new Crashlytics());
    }

    private Retrofit retrofit;

    public static synchronized Davakhana instance() {
        return davakhana;
    }

    public Retrofit api() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(Constant.API_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

    public ApiService apiService() {
        return api().create(ApiService.class);
    }

    public DavakhanaSharedPreferences dsp() {
        if (dsp == null)
            dsp = new DavakhanaSharedPreferences(this);
        return dsp;
    }

    private JsonObject user;
    private JsonObject client;
    private int bookingCount, invoiceCount, chatCount;

    private JsonArray services;

    public JsonArray getServices() {
        return services;
    }

    public void setServices(JsonArray services) {
        this.services = services;
    }

    public JsonObject getUser() {
        return user;
    }

    public void setUser(JsonObject user) {
        this.user = user;
    }

    public JsonObject getClient() {
        return client;
    }

    public void setClient(JsonObject client) {
        this.client = client;
    }

}
