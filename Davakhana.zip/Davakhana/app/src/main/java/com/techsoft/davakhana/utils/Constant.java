package com.techsoft.davakhana.utils;


import com.techsoft.davakhana.R;


public class Constant {

    /* container id */
    public static final int
            CONTAINER_GUEST = R.id.container_guest,
            CONTAINER_MAIN = R.id.container_main,
            PERMISSION_CODE = 200;

    public static final String
            PACKAGE = Constant.class.getCanonicalName(),
            APP_TYPE = "User",
            REFERENCE_CODE = "591d0ca222d92",
            OS = "Android",
    //BASE_URL = "https://www.bigappcompany.com.au/",
            BASE_URL = "http://google.com.in/",
            API_URL = BASE_URL + "api/",
            BUNDLE_OTP = PACKAGE + ".otp",
            BUNDLE_PASSWORD = PACKAGE + ".password",
            BUNDLE_MOBILE_OR_EMAIL = PACKAGE + ".mobile_or_email",
            BUNDLE_FRAGMENT_NAME = PACKAGE + ".fragment",
            BUNDLE_IS_VISIBLE = PACKAGE + ".is_visible",
            DATE_TIME_US = "yyyy-MM-dd hh:mm:ss",
            DATE_TIME_INDIA = "dd-MM-yyyy hh:mm aa",
            FORMAT_BLOG = "LLL dd, yyyy",
            FORMAT_BOOKING = "K:mm a - LLL dd, yyyy",
            NO_INTERNET_CONNECTION = "No internet connection found.",
            UNKNOWN_ERROR = "An unknown error has occurred. Try again.",
            NOTIFICATION_TARGET = "activity.to.handle.notification",
            NOTIFICATION_FOREGROUND = "handle.foreground.notification",
            NOTIFICATION_DATA = "handle.foreground.notification.data",
            NOTIFICATION_MESSAGE = "handle.foreground.notification.message";


    public static final String[]
            READ_EXTERNAL_STORAGE = {"android.permission.READ_EXTERNAL_STORAGE"},
            CALL_PHONE = {"android.permission.CALL_PHONE"};

}