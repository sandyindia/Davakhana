package com.techsoft.davakhana.widgets;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.InputFilter;
import android.text.method.MovementMethod;
import android.view.View;
import android.view.inputmethod.EditorInfo;

import androidx.annotation.ColorInt;
import androidx.annotation.Px;
import androidx.appcompat.widget.AppCompatEditText;

/**
 * Created by root on 24/8/17.
 */

public class PinCode extends AppCompatEditText {

    private static final String TAG = "PinView";

    private static final boolean DBG = false;

    private static final int DEFAULT_COUNT = 4;

    private static final InputFilter[] NO_FILTERS = new InputFilter[0];

    private int mPinItemCount;

    private float mPinItemSize;
    private int mPinItemRadius;
    private int mPinItemSpacing;

    private ColorStateList mBorderColor;
    private int mCurBorderColor = Color.BLACK;
    private int mBorderWidth;

    private final Rect mTextRect = new Rect();
    private final RectF mBoxBorderRect = new RectF();
    private final Path mPath = new Path();
    private final PointF mBoxCenterPoint = new PointF();

    private ValueAnimator mDefaultAddAnimator;
    private boolean isAnimationEnable = false;

    public PinCode(Context context) {
        super(context);
    }

    private void setMaxLength(int maxLength) {
        if (maxLength >= 0) {
            setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        } else {
            setFilters(NO_FILTERS);
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int widthMode = View.MeasureSpec.getMode(widthMeasureSpec);
        int heightMode = View.MeasureSpec.getMode(heightMeasureSpec);
        int widthSize = View.MeasureSpec.getSize(widthMeasureSpec);
        int heightSize = View.MeasureSpec.getSize(heightMeasureSpec);

        int width;
        int height;

        float boxHeight = mPinItemSize;

        if (widthMode == View.MeasureSpec.EXACTLY) {
            // Parent has told us how big to be. So be it.
            width = widthSize;
        } else {
            float boxesWidth = (mPinItemCount - 1) * mPinItemSpacing + mPinItemCount * boxHeight;
            width = Math.round(boxesWidth + getPaddingRight() + getPaddingLeft());
            if (mPinItemSpacing == 0) {
                width -= 2 * (mPinItemCount - 1) * mBorderWidth;
            }
        }

        if (heightMode == View.MeasureSpec.EXACTLY) {
            // Parent has told us how big to be. So be it.
            height = heightSize;
        } else {
            height = Math.round(boxHeight + getPaddingTop() + getPaddingBottom());
        }

        setMeasuredDimension(width, height);
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);

        if (start != text.length()) {
            moveCursorToEnd();
        }

        if (isAnimationEnable) {
            final boolean isAdd = lengthAfter - lengthBefore > 0;
            if (isAdd) {
                if (mDefaultAddAnimator != null) {
                    mDefaultAddAnimator.end();
                    mDefaultAddAnimator.start();
                }
            }
        }
    }

    @Override
    protected void onFocusChanged(boolean focused, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(focused, direction, previouslyFocusedRect);

        if (focused) {
            moveCursorToEnd();
        }
    }

    @Override
    protected void onSelectionChanged(int selStart, int selEnd) {
        super.onSelectionChanged(selStart, selEnd);

        if (selEnd != getText().length()) {
            moveCursorToEnd();
        }
    }

    private void moveCursorToEnd() {
        setSelection(getText().length());
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();

        if (mBorderColor == null || mBorderColor.isStateful()) {
            updateColors();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.save();
        canvas.restore();
    }

    private void updateRoundRectPath(RectF rectF, float rx, float ry, boolean l, boolean r) {
        updateRoundRectPath(rectF, rx, ry, l, r, r, l);
    }

    private void updateRoundRectPath(RectF rectF, float rx, float ry,
                                     boolean tl, boolean tr, boolean br, boolean bl) {
        mPath.reset();

        float l = rectF.left;
        float t = rectF.top;
        float r = rectF.right;
        float b = rectF.bottom;

        float w = r - l;
        float h = b - t;

        float lw = w - 2 * rx;// line width
        float lh = h - 2 * ry;// line height

        mPath.moveTo(l, t + ry);

        if (tl) {
            mPath.rQuadTo(0, -ry, rx, -ry);// top-left corner
        } else {
            mPath.rLineTo(0, -ry);
            mPath.rLineTo(rx, 0);
        }

        mPath.rLineTo(lw, 0);

        if (tr) {
            mPath.rQuadTo(rx, 0, rx, ry);// top-right corner
        } else {
            mPath.rLineTo(rx, 0);
            mPath.rLineTo(0, ry);
        }

        mPath.rLineTo(0, lh);

        if (br) {
            mPath.rQuadTo(0, ry, -rx, ry);// bottom-right corner
        } else {
            mPath.rLineTo(0, ry);
            mPath.rLineTo(-rx, 0);
        }

        mPath.rLineTo(-lw, 0);

        if (bl) {
            mPath.rQuadTo(-rx, 0, -rx, -ry);// bottom-left corner
        } else {
            mPath.rLineTo(-rx, 0);
            mPath.rLineTo(0, -ry);
        }

        mPath.rLineTo(0, -lh);

        mPath.close();
    }

    private void updateBoxRectF(int i) {
        float startX = (getWidth() - (mPinItemCount - 1) * mPinItemSpacing - mPinItemCount * mPinItemSize) / 2;
        if (mPinItemSpacing == 0) {
            startX += (mPinItemCount - 1) * mBorderWidth;
        }
        float left = startX + mPinItemSize * i + mPinItemSpacing * i + mBorderWidth;
        if (mPinItemSpacing == 0 && i > 0) {
            left = left - 2 * mBorderWidth * i;
        }
        float right = left + mPinItemSize - 2 * mBorderWidth;
        float top = mBorderWidth + getPaddingTop();
        float bottom = top + mPinItemSize - 2 * mBorderWidth;

        mBoxBorderRect.set(left, top, right, bottom);
    }

    private void drawTextAtBox(Canvas canvas, Paint paint, CharSequence text, int charAt) {
        paint.getTextBounds(text.toString(), charAt, charAt + 1, mTextRect);
        float cx = mBoxCenterPoint.x;
        float cy = mBoxCenterPoint.y;
        float x = cx - Math.abs(mTextRect.width()) / 2 - mTextRect.left;
        float y = cy + Math.abs(mTextRect.height()) / 2 - mTextRect.bottom;// always center vertical
        canvas.drawText(text, charAt, charAt + 1, x, y, paint);
    }

    /**
     * For seeing the font position
     */

    private void updateColors() {
        boolean inval = false;

        int color;
        if (mBorderColor != null) {
            color = mBorderColor.getColorForState(getDrawableState(), 0);
        } else {
            color = getCurrentTextColor();
        }

        if (color != mCurBorderColor) {
            mCurBorderColor = color;
            inval = true;
        }

        if (inval) {
            invalidate();
        }
    }

    private void updateCenterPoint() {
        float cx = mBoxBorderRect.left + Math.abs(mBoxBorderRect.width()) / 2;
        float cy = mBoxBorderRect.top + Math.abs(mBoxBorderRect.height()) / 2;
        mBoxCenterPoint.set(cx, cy);
    }

    private static boolean isPasswordInputType(int inputType) {
        final int variation =
                inputType & (EditorInfo.TYPE_MASK_CLASS | EditorInfo.TYPE_MASK_VARIATION);
        return variation
                == (EditorInfo.TYPE_CLASS_TEXT | EditorInfo.TYPE_TEXT_VARIATION_PASSWORD)
                || variation
                == (EditorInfo.TYPE_CLASS_TEXT | EditorInfo.TYPE_TEXT_VARIATION_WEB_PASSWORD)
                || variation
                == (EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_VARIATION_PASSWORD);
    }

    @Override
    protected MovementMethod getDefaultMovementMethod() {
        // we don't need arrow key, return null will also disable the copy/paste/cut pop-up menu.
        return null;
    }

    /**
     * Sets the border color for all the states (normal, selected,
     * focused) to be this color.
     *
     * @param color A color value in the form 0xAARRGGBB.
     *              Do not pass a resource ID. To get a color value from a resource ID, call
     *
     * @attr ref R.styleable#PinView_borderColor
     * @see #setBorderColor(ColorStateList)
     * @see #getBorderColors()
     */
    public void setBorderColor(@ColorInt int color) {
        mBorderColor = ColorStateList.valueOf(color);
        updateColors();
    }

    /**
     * Sets the border color.
     *
     * @attr ref R.styleable#PinView_borderColor
     * @see #setBorderColor(int)
     * @see #getBorderColors()
     */
    public void setBorderColor(ColorStateList colors) {
        if (colors == null) {
            throw new NullPointerException();
        }

        mBorderColor = colors;
        updateColors();
    }

    /**
     * Gets the border colors for the different states (normal, selected, focused) of the PinView.
     *
     * @attr ref R.styleable#PinView_borderColor
     * @see #setBorderColor(ColorStateList)
     * @see #setBorderColor(int)
     */
    public ColorStateList getBorderColors() {
        return mBorderColor;
    }

    /**
     * <p>Return the current color selected for normal border.</p>
     *
     * @return Returns the current border color.
     */
    @ColorInt
    public int getCurrentBorderColor() {
        return mCurBorderColor;
    }

    /**
     * Sets the border width.
     *
     * @attr ref R.styleable#PinView_borderWidth
     * @see #getBorderWidth()
     */
    public void setBorderWidth(@Px int borderWidth) {
        mBorderWidth = borderWidth;
    }

    /**
     * @return Returns the width of the box's border.
     * @see #setBorderWidth(int)
     */
    @Px
    public int getBorderWidth() {
        return mBorderWidth;
    }

    /**
     * Sets the count of boxes.
     *
     * @attr ref R.styleable#PinView_boxCount
     * @see #getBoxCount()
     * @deprecated Use {@link #setItemCount(int)} instead.
     */
    @Deprecated
    public void setBoxCount(int len) {
        setItemCount(len);
    }

    /**
     * @return Returns the count of the boxes.
     * @see #setBoxCount(int)
     * @deprecated Use {@link #getItemCount()} instead.
     */
    @Deprecated
    public int getBoxCount() {
        return getItemCount();
    }

    /**
     * Sets the count of items.
     *
     * @attr ref R.styleable#PinView_itemCount
     * @see #getItemCount()
     */
    public void setItemCount(int count) {
        mPinItemCount = count;
        setMaxLength(count);
        requestLayout();
    }

    /**
     * @return Returns the count of items.
     * @see #setItemCount(int)
     */
    public int getItemCount() {
        return mPinItemCount;
    }

    /**
     * Sets the radius of box's border.
     *
     * @attr ref R.styleable#PinView_boxRadius
     * @see #getBoxRadius()
     * @deprecated Use {@link #setItemRadius(int)} instead.
     */
    @Deprecated
    public void setBoxRadius(@Px int pinBoxRadius) {
        setItemRadius(pinBoxRadius);
    }

    /**
     * @return Returns the radius of boxes's border.
     * @see #setBoxRadius(int)
     * @deprecated Use {@link #getItemRadius()} instead.
     */
    @Px
    @Deprecated
    public int getBoxRadius() {
        return getItemRadius();
    }

    /**
     * Sets the radius of square.
     *
     * @attr ref R.styleable#PinView_itemRadius
     * @see #getItemRadius()
     */
    public void setItemRadius(@Px int itemRadius) {
        mPinItemRadius = itemRadius;
    }

    /**
     * @return Returns the radius of square.
     * @see #setItemRadius(int)
     */
    @Px
    public int getItemRadius() {
        return mPinItemRadius;
    }

    /**
     * Specifies extra space between the boxes.
     *
     * @attr ref R.styleable#PinView_boxMargin
     * @see #getBoxMargin()
     * @deprecated Use {@link #setItemSpacing(int)} instead.
     */
    @Deprecated
    public void setBoxMargin(@Px int pinBoxMargin) {
        setItemSpacing(pinBoxMargin);
    }

    /**
     * @return Returns the margin between of the boxes.
     * @see #setBoxMargin(int)
     * @deprecated Use {@link #getItemSpacing()} instead.
     */
    @Px
    @Deprecated
    public int getBoxMargin() {
        return getItemSpacing();
    }


    /**
     * Specifies extra space between two items.
     *
     * @attr ref R.styleable#PinView_itemSpacing
     * @see #getItemSpacing()
     */
    public void setItemSpacing(@Px int itemSpacing) {
        mPinItemSpacing = itemSpacing;
        requestLayout();
    }

    /**
     * @return Returns the spacing between two items.
     * @see #setItemSpacing(int)
     */
    @Px
    public int getItemSpacing() {
        return mPinItemSpacing;
    }

    /**
     * Sets the height and width of box.
     *
     * @attr ref R.styleable#PinView_boxHeight
     * @see #getBoxHeight()
     * @deprecated Use {@link #setItemSize(float)} instead.
     */
    @Deprecated
    public void setBoxHeight(float boxHeight) {
        setItemSize(boxHeight);
    }

    /**
     * @return Returns the height of box.
     * @see #setBoxHeight(float)
     * @deprecated Use {@link #getItemSize()} instead.
     */
    @Deprecated
    public float getBoxHeight() {
        return getItemSize();
    }

    /**
     * Sets the height and width of item.
     *
     * @attr ref R.styleable#PinView_itemSize
     * @see #getItemSize()
     */
    public void setItemSize(float itemSize) {
        mPinItemSize = itemSize;
    }

    /**
     * @return Returns the size of item.
     * @see #setBoxHeight(float)
     */
    public float getItemSize() {
        return mPinItemSize;
    }

    /**
     * Specifies whether the text animation should be enabled or disabled.
     * By the default, the animation is disabled.
     *
     * @param enable True to start animation when adding text, false to transition immediately
     */
    public void setAnimationEnable(boolean enable) {
        isAnimationEnable = enable;
    }
}
