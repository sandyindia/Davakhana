package com.techsoft.davakhana.interfaces;

public interface OnFragmentCreated {

    void onFragmentCreated(String data);
}
