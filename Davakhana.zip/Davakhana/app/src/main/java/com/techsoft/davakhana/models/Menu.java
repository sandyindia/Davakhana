package com.techsoft.davakhana.models;

/**
 * Created by root on 29/8/17.
 */

public class Menu {

    private String title;
    private int icon;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }
}
