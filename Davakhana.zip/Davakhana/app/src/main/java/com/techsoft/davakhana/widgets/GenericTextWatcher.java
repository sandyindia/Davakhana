package com.techsoft.davakhana.widgets;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

/**
 * Created by root on 31/8/17.
 */

public class GenericTextWatcher implements TextWatcher {
    private EditText editText;

    public GenericTextWatcher(EditText editText) {
        this.editText = editText;
    }

    @Override
    public void afterTextChanged(Editable editable) {
        String text = editable.toString();
        if (text.length() == 1)
            editText.requestFocus();
    }

    @Override
    public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
    }

    @Override
    public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
    }
}
