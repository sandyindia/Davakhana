package com.techsoft.davakhana.fragments;


import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;

import com.techsoft.davakhana.R;
import com.techsoft.davakhana.activities.MainActivity;
import com.techsoft.davakhana.utils.Constant;

/*
import com.nw.nextwebuser.NextWeb;
import com.nw.nextwebuser.R;
import com.nw.nextwebuser.activities.MainActivity;
import com.nw.nextwebuser.utils.Constant;
import com.nw.nextwebuser.utils.DavakhanaSharedPreferences;
*/

/**
 splash screen fragment
 */
public class SplashScreenFragment extends BaseFragment {

    private static final String TAG = SplashScreenFragment.class.getCanonicalName();

    public SplashScreenFragment() {
        // Required empty public constructor
    }

    private boolean isLoggedIn = false;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* isLoggedIn = NextWeb.instance().nsp().getPreference(DavakhanaSharedPreferences.UID) != null
                && NextWeb.instance().nsp().isRemembered(DavakhanaSharedPreferences.REMEMBER_ME);*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = null;
        if (isLoggedIn)
            startAnActivity(getActivity(), MainActivity.class);
        else {
            view = inflater.inflate(R.layout.fragment_splash_screen, container, false);
            init(view);
        }
        return view;
    }

    private void init(View v){
       /* workingfine top_to_middle*/
        v.findViewById(R.id.image_view_logo).setAnimation(animate(getActivity(), R.anim.top_to_middle));
        v.findViewById(R.id.progress_bar_circular).setVisibility(View.VISIBLE);
        nextFragment();
    }

    private Handler handler = null;
    private Runnable runnable;

    private void nextFragment(){
        runnable = new Runnable() {
            @Override
            public void run() {
                replaceFragment(getActivity(), Constant.CONTAINER_GUEST, new LoginFragment());
            }
        };
        handler = new Handler();
        handler.postDelayed(runnable, 3000);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (handler != null) handler.removeCallbacks(runnable);
    }

    @Override
    public void onResume() {
        super.onResume();
        nextFragment();
    }
}
