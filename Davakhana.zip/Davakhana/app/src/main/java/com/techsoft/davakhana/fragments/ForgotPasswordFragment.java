package com.techsoft.davakhana.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.google.gson.JsonObject;
import com.techsoft.davakhana.Davakhana;
import com.techsoft.davakhana.R;
import com.techsoft.davakhana.utils.Constant;
import com.techsoft.davakhana.utils.ErrorUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 */
public class ForgotPasswordFragment extends BaseFragment implements View.OnClickListener, Callback<JsonObject> {


    public ForgotPasswordFragment() {
        // Required empty public constructor
    }

    public static final String TAG = ForgotPasswordFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_forgot_password, container, false);
        init(view);
        return view;
    }

    @Override
    public void onPause() {
        super.onPause();
        if (apiCall != null)
            apiCall.cancel();
    }

    @Override
    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
        progressBar.setVisibility(View.GONE);
        if (response.isSuccessful()) {
            showToast(getActivity(), response.body().get("message").getAsString());
            if (response.body().get("success").getAsBoolean())
                gotoNextFragment(response.body().get("OTP").getAsString());
        }else showToast(getActivity(), ErrorUtils.parseError(response).getMessage());
    }

    @Override
    public void onFailure(Call<JsonObject> call, Throwable t) {
        progressBar.setVisibility(View.GONE);
        call.cancel();
        showToast(getActivity(), t instanceof IOException ? Constant.NO_INTERNET_CONNECTION : Constant.UNKNOWN_ERROR);
    }

    private String[] tags = {TAG, ForgotPasswordFragment.TAG};

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.tv_btn_start:
                popUpFromBackStack(getActivity());
                break;

            case R.id.tv_btn_end:
                if (inputsAreValid())
                    apiOTP();
                break;
        }
    }

    private Call<JsonObject> apiCall = null;

    /* call login api here */
    private void apiOTP() {
        if (isOnline(getActivity())) {
            progressBar.setVisibility(View.VISIBLE);
            Map<String, String> request = new HashMap<>();
            request.put("app", Constant.APP_TYPE);
            request.put("reference_code", Constant.REFERENCE_CODE);
            request.put("mobile_or_email", mobileOrEmail);
            apiCall = Davakhana.instance().apiService().forgotPassword(request);
            apiCall.enqueue(this);
        }
    }

    private void gotoNextFragment(String otp) {
        Bundle bundle = new Bundle();
        bundle.putString(Constant.BUNDLE_MOBILE_OR_EMAIL, mobileOrEmail);
        bundle.putString(Constant.BUNDLE_OTP, otp);
        // a fragment to redirect from OTPFragment fragment
        bundle.putString(Constant.BUNDLE_FRAGMENT_NAME, PasswordResetFragment.class.getSimpleName());
        Fragment fragment = new OTPFragment();
        fragment.setArguments(bundle);
        addFragmentToStack(getActivity(), Constant.CONTAINER_GUEST, tags, fragment);
    }

    private String mobileOrEmail = "";

    /* validate all input fields */
    private boolean inputsAreValid() {
        boolean status = false;
        mobileOrEmail = etMobileEmail.getText().toString().trim();
        if (mobileOrEmail.isEmpty())
            showToast(getActivity(), "Mobile/Email is mandatory.");
        else status = true;
        return status;
    }

    private EditText etMobileEmail;
    private ProgressBar progressBar;

    private void init(View view) {
        TextView tvTitle = (TextView) view.findViewById(R.id.frag_forgot_pass_tv);
        tvTitle.setTypeface(font(getActivity(), "handmade.otf"));

        etMobileEmail = (EditText) view.findViewById(R.id.mob_or_mail);
        etMobileEmail.setImeOptions(EditorInfo.IME_ACTION_DONE);

        /* set listeners */
        view.findViewById(R.id.tv_btn_start).setOnClickListener(this);
        view.findViewById(R.id.tv_btn_end).setOnClickListener(this);
        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_circular);

        /* animate layout */
        view.findViewById(R.id.frag_forgot_pass_ll).setAnimation(animate(getActivity(), R.anim.left_to_right));
    }
}
