package com.techsoft.davakhana.models;

/**
 * Created by root on 25/9/17.
 */

public class ApiError {


    private int statusCode;
    private String endpoint, message = "Unknown Erroe.";

    public int getStatusCode() {
        return statusCode;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public String getMessage() {
        return message;
    }
}
