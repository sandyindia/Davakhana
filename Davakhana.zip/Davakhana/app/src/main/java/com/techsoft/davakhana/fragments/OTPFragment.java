package com.techsoft.davakhana.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.techsoft.davakhana.R;
import com.techsoft.davakhana.utils.Constant;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 */
public class OTPFragment extends BaseFragment implements View.OnClickListener{


    public OTPFragment() {
        // Required empty public constructor
    }

    public static final String TAG = OTPFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ot, container, false);
        bundle = getArguments();
        if (bundle != null)
            init(view);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.frag_otp_tv_resend:
                showToast(getActivity(), "TODO: Resend OTP.");
                break;

            case R.id.frag_otp_tv_next:
                if (otpIsValid())
                    gotoNextFragment();
                break;
        }
    }

    private void gotoNextFragment() {
        String fragName = bundle.getString(Constant.BUNDLE_FRAGMENT_NAME);
        if (fragName != null) {
            String[] tags = {TAG, fragName};
            Fragment fragment = null;
            if (fragName.equalsIgnoreCase("PasswordResetFragment")){
                    fragment = new PasswordResetFragment();
            }
            if (fragment != null) {
                fragment.setArguments(bundle);
                addFragmentToStack(getActivity(), Constant.CONTAINER_GUEST, tags, fragment);
            }
        }
    }

    private Bundle bundle = null;

    private boolean otpIsValid() {
        boolean status = false;
        String otp = etOTP.getText().toString().trim();
        if (otp.isEmpty())
            showToast(getActivity(), "Please enter your OTP.");
        else if (!otp.equals(bundle.getString(Constant.BUNDLE_OTP)))
            showToast(getActivity(), "Your OTP is invalid.");
        else status = true;
        return status;
    }

    /* call login api here */
    private void apiOTP() {
        showToast(getActivity(), "TODO: Call Login api");
    }

    private EditText etOTP;

    private void init(View view) {
       /* TextView tvOTPTitle = view.findViewById(R.id.frag_otp_tv);
        String title = "Your OTP sent to " + bundle.getString(Constant.BUNDLE_MOBILE_OR_EMAIL);
        tvOTPTitle.setText(title);

        etOTP = (EditText) view.findViewById(R.id.frag_otp_et);*/

        /* set listeners */
        view.findViewById(R.id.frag_otp_tv_resend).setOnClickListener(this);
        view.findViewById(R.id.frag_otp_tv_next).setOnClickListener(this);

        /* animate layout */
        view.findViewById(R.id.frag_otp_ll).setAnimation(animate(getActivity(), R.anim.left_to_right));
    }

}
