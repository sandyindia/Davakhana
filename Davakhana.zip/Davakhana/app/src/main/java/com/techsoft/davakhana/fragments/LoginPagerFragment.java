package com.techsoft.davakhana.fragments;


import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.techsoft.davakhana.R;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 * Use the {@link LoginPagerFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LoginPagerFragment extends BaseFragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            position = getArguments().getInt(POSITION);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(LAYOUTS[position], container, false);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        TextView tvSubtitle = (TextView) view.findViewById(R.id.tv_subtitle);

        tvTitle.setTypeface(font(getActivity(), "Montserrat-Light.otf"));
        Typeface typeface = font(getActivity(), "handmade.otf");
        tvSubtitle.setTypeface(typeface);
        if (position != 1){
            TextView tvDesc = (TextView) view.findViewById(R.id.tv_description);
            tvDesc.setTypeface(typeface);
        }
        return view;
    }

    static final int[] LAYOUTS = {
            R.layout.fragment_login_slide_1,
            R.layout.fragment_login_slide_2,
            R.layout.fragment_login_slide_3,
            R.layout.fragment_login_slide_4
    };

    // the fragment initialization parameters
    private static final String POSITION = LoginPagerFragment.class.getCanonicalName() + ".position";

    private int position = 0;

    public static LoginPagerFragment newInstance(int param) {
        LoginPagerFragment fragment = new LoginPagerFragment();
        Bundle args = new Bundle();
        args.putInt(POSITION, param);
        fragment.setArguments(args);
        return fragment;
    }
}
