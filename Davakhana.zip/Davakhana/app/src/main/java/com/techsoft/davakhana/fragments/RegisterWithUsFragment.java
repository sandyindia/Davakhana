package com.techsoft.davakhana.fragments;


import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.google.gson.JsonObject;
import com.techsoft.davakhana.Davakhana;
import com.techsoft.davakhana.R;
import com.techsoft.davakhana.utils.Constant;
import com.techsoft.davakhana.utils.ErrorUtils;
import com.techsoft.davakhana.widgets.GenericTextWatcher;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 */
public class RegisterWithUsFragment extends BaseFragment implements View.OnClickListener, Callback<JsonObject> {


    public RegisterWithUsFragment() {
        // Required empty public constructor
    }

    public static final String TAG = RegisterWithUsFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register_with_us, container, false);
        init(view);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.tv_btn_start:
                popUpFromBackStack(getActivity());
                break;

            case R.id.tv_btn_end:
                if (inputsAreValid())
                    apiOTP();
                break;
        }
    }

    @Override
    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
        progressBar.setVisibility(View.GONE);
        if (response.isSuccessful()) {
            showToast(getActivity(), response.body().get("message").getAsString());
            if (response.body().get("success").getAsBoolean())
                gotoNextFragment(response.body().get("OTP").getAsString());
        }else showToast(getActivity(), ErrorUtils.parseError(response).getMessage());
    }

    @Override
    public void onFailure(Call<JsonObject> call, Throwable t) {
        progressBar.setVisibility(View.GONE);
        call.cancel();
        showToast(getActivity(), t instanceof IOException ? Constant.NO_INTERNET_CONNECTION : Constant.UNKNOWN_ERROR);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (apiCall != null)
            apiCall.cancel();
    }

    private String[] tags = {TAG, OTPFragment.TAG};

    private Call<JsonObject> apiCall = null;

    /* call login api here */
    private void apiOTP() {
        if (isOnline(getActivity())) {
            progressBar.setVisibility(View.VISIBLE);
            Map<String, String> body = new HashMap<>();
            body.put("mobile_or_email", mobileOrEmail);
            body.put("reference_code",Constant.REFERENCE_CODE);
            apiCall = Davakhana.instance().apiService().otp(body);
            apiCall.enqueue(this);
        }
    }

    private String mobileOrEmail = "", password = "";

    private void gotoNextFragment(String otp) {
        Bundle bundle = new Bundle();
        bundle.putString(Constant.BUNDLE_MOBILE_OR_EMAIL, mobileOrEmail);
        bundle.putString(Constant.BUNDLE_PASSWORD, password);
        bundle.putString(Constant.BUNDLE_OTP, otp);
        // a fragment to redirect from OTPFragment fragment
        bundle.putString(Constant.BUNDLE_FRAGMENT_NAME, RegisterCompleteFragment.class.getSimpleName());
        Fragment fragment = new OTPFragment();
        fragment.setArguments(bundle);
        addFragmentToStack(getActivity(), Constant.CONTAINER_GUEST, tags, fragment);
    }

    /* validate all input fields */
    private boolean inputsAreValid() {
        boolean status = false;
        mobileOrEmail = etMobileEmail.getText().toString().trim();
        String pin1 = etPin1.getText().toString().trim();
        String pin2 = etPin2.getText().toString().trim();
        String pin3 = etPin3.getText().toString().trim();
        String pin4 = etPin4.getText().toString().trim();

        String confirmPin1 = etConfirmPin1.getText().toString().trim();
        String confirmPin2 = etConfirmPin2.getText().toString().trim();
        String confirmPin3 = etConfirmPin3.getText().toString().trim();
        String confirmPin4 = etConfirmPin4.getText().toString().trim();

        password = pin1 + pin2 + pin3 + pin4;

        if (mobileOrEmail.isEmpty())
            showToast(getActivity(), "Mobile/Email is mandatory.");
        else if (pin1.isEmpty() || pin2.isEmpty() || pin3.isEmpty() || pin4.isEmpty())
            showToast(getActivity(), "Your four digit pin code is compulsory.");
        else if (confirmPin1.isEmpty() || confirmPin2.isEmpty() || confirmPin3.isEmpty()
                || confirmPin4.isEmpty())
            showToast(getActivity(), "Your must confirm four digit pin.");
        else if (!password.equals(confirmPin1 + confirmPin2 + confirmPin3 + confirmPin4))
            showToast(getActivity(), "Your four digit pins do not match.");
        else status = true;
        return status;
    }

    private EditText etMobileEmail, etPin1, etPin2, etPin3, etPin4, etConfirmPin1, etConfirmPin2,
            etConfirmPin3, etConfirmPin4;
    private ProgressBar progressBar;

    private void init(View view) {
        /*TextView tvTitle = (TextView) view.findViewById(R.id.frag_register_with_us_title);
        tvTitle.setTypeface(font(getActivity(), "handmade.otf"));*/

        etMobileEmail = (EditText) view.findViewById(R.id.mob_or_mail);

        etPin1 = (EditText) view.findViewById(R.id.et_pin_1);
        etPin2 = (EditText) view.findViewById(R.id.et_pin_2);
        etPin3 = (EditText) view.findViewById(R.id.et_pin_3);
        etPin4 = (EditText) view.findViewById(R.id.et_pin_4);
        etPin4.setImeOptions(EditorInfo.IME_ACTION_NEXT);

        etConfirmPin1 = (EditText) view.findViewById(R.id.et_pin_cp_1);
        etConfirmPin2 = (EditText) view.findViewById(R.id.et_pin_cp_2);
        etConfirmPin3 = (EditText) view.findViewById(R.id.et_pin_cp_3);
        etConfirmPin4 = (EditText) view.findViewById(R.id.et_pin_cp_4);

        /* set listeners */
        view.findViewById(R.id.tv_btn_start).setOnClickListener(this);
        view.findViewById(R.id.tv_btn_end).setOnClickListener(this);

        etPin1.addTextChangedListener(new GenericTextWatcher(etPin2));
        etPin2.addTextChangedListener(new GenericTextWatcher(etPin3));
        etPin3.addTextChangedListener(new GenericTextWatcher(etPin4));

        etConfirmPin1.addTextChangedListener(new GenericTextWatcher(etConfirmPin2));
        etConfirmPin2.addTextChangedListener(new GenericTextWatcher(etConfirmPin3));
        etConfirmPin3.addTextChangedListener(new GenericTextWatcher(etConfirmPin4));

        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_circular);

        /* animate layout */
        view.findViewById(R.id.frag_register_with_us_ll).setAnimation(animate(getActivity(), R.anim.left_to_right));
    }
}
