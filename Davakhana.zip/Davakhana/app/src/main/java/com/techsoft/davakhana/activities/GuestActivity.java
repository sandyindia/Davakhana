package com.techsoft.davakhana.activities;

import android.os.Bundle;

import com.techsoft.davakhana.R;
import com.techsoft.davakhana.fragments.SplashScreenFragment;
import com.techsoft.davakhana.utils.Constant;

public class GuestActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);
        addFragment(Constant.CONTAINER_GUEST, new SplashScreenFragment(), null);
    }
}
