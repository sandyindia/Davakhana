package com.techsoft.davakhana.fragments;


import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.gson.JsonObject;

import com.techsoft.davakhana.Davakhana;
import com.techsoft.davakhana.R;
import com.techsoft.davakhana.activities.MainActivity;
import com.techsoft.davakhana.utils.Constant;
import com.techsoft.davakhana.utils.DavakhanaSharedPreferences;
import com.techsoft.davakhana.utils.ErrorUtils;
import com.techsoft.davakhana.utils.ImageRelated;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 */
public class RegisterCompleteFragment extends BaseFragment implements View.OnClickListener, Callback<JsonObject> {


    public RegisterCompleteFragment() {
        // Required empty public constructor
    }

    public static final String TAG = RegisterCompleteFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register_complete, container, false);
        init(view);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.frag_register_complete_submit:
                if (inputsAreValid())
                    apiRegister();
                break;

            case R.id.image_view_avatar:
                if (notGranted(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE))
                    requestPermissions(Constant.READ_EXTERNAL_STORAGE, Constant.PERMISSION_CODE);
                else openPhotoChooser();
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch(requestCode){
            case Constant.PERMISSION_CODE:
                boolean readAccepted = grantResults[0]== PackageManager.PERMISSION_GRANTED;
                if (readAccepted)
                    openPhotoChooser();
                else showToast(getActivity(), "You must accept read permission.");
                break;
        }
    }

    private Uri mOutputFileUri = null;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == ImageRelated.REQUEST_PHOTO && data != null) {
            mOutputFileUri = data.getData();
            Glide.with(getActivity()).load(mOutputFileUri).into(ivAvatar);
        } else showToast(getActivity(), "Oops! Couldn't retrieve image.");
    }

    @Override
    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
        progressBar.setVisibility(View.GONE);
        if (response.isSuccessful()) {
            if (response.body().get("status").getAsBoolean()) {
                addToSharedPreferences(response.body());
            }else showToast(getActivity(), response.body().get("message").getAsString());
        }else showToast(getActivity(), ErrorUtils.parseError(response).getMessage());
    }

    @Override
    public void onFailure(Call<JsonObject> call, Throwable t) {
        progressBar.setVisibility(View.GONE);
        call.cancel();
        showToast(getActivity(), t instanceof IOException ? Constant.NO_INTERNET_CONNECTION : Constant.UNKNOWN_ERROR);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (apiCall != null)
            apiCall.cancel();
    }

    private void addToSharedPreferences(JsonObject body) {
        DavakhanaSharedPreferences nsp = new DavakhanaSharedPreferences(getContext());
        nsp.sharePreference(DavakhanaSharedPreferences.UID, body.get("uid").getAsString());
        nsp.sharePreference(DavakhanaSharedPreferences.TOKEN, body.get("api_token").getAsString());
        nsp.sharePreference(DavakhanaSharedPreferences.MOBILE_OR_EMAIL, email);
        startAnActivity(getActivity(), MainActivity.class);
    }

    private Call<JsonObject> apiCall = null;

    /* call login api here */
    private void apiRegister() {
        if (isOnline(getActivity())){
            progressBar.setVisibility(View.VISIBLE);
            Map<String, RequestBody> map = new HashMap<>();
            map.put("name", createPartFromString(firstName));
            map.put("surname", createPartFromString(lastName));
            map.put("mobile", createPartFromString(mobile));
            map.put("email", createPartFromString(email));
            map.put("suburban", createPartFromString(suburb));
            map.put("website", createPartFromString(website));
            map.put("password", createPartFromString(password));
            map.put("reference_code", createPartFromString(Constant.REFERENCE_CODE));
            map.put("os", createPartFromString(Constant.OS));
            apiCall = Davakhana.instance().apiService().register(map, ImageRelated.prepareFilePart(getActivity(), "image", mOutputFileUri));
            apiCall.enqueue(this);
        }
    }

    private ImageView ivAvatar;
    private EditText etFirstName, etLastName, etMobile, etEmail, etSubUrb, etWebsite;
    private ProgressBar progressBar;
    private String password;

    private void init(View view) {
        ivAvatar = (ImageView) view.findViewById(R.id.image_view_avatar);
        etFirstName = (EditText) view.findViewById(R.id.form_user_first_name);
        etMobile = (EditText) view.findViewById(R.id.form_user_mobile);
        etEmail = (EditText) view.findViewById(R.id.form_user_email);
        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_circular);
        Bundle bundle = getArguments();
        if (bundle != null) {
            password = bundle.getString(Constant.BUNDLE_PASSWORD);
            setMobileOrEmail(bundle.getString(Constant.BUNDLE_MOBILE_OR_EMAIL));
            ivAvatar.setOnClickListener(this);
            view.findViewById(R.id.frag_register_complete_submit).setOnClickListener(this);
        }
    }

    private void setMobileOrEmail(String mobileOrEmail) {
        if (mobileOrEmail.contains("@"))
            initEditText(etEmail, mobileOrEmail);
        else initEditText(etMobile, mobileOrEmail);
    }

    private String firstName, lastName, mobile, email, suburb, website;

    /* validate all input fields */
    private boolean inputsAreValid() {
        boolean status = false;
        firstName = etFirstName.getText().toString().trim();
        lastName = etLastName.getText().toString().trim();
        mobile = etMobile.getText().toString().trim();
        email = etEmail.getText().toString().trim();
        suburb = etSubUrb.getText().toString().trim();
        website = etWebsite.getText().toString().trim();
        if (mOutputFileUri == null)
            showToast(getActivity(), "Your profile photo is required.");
        else if (firstName.isEmpty())
            showToast(getActivity(), "First Name is mandatory.");
        else if (lastName.isEmpty())
            showToast(getActivity(), "Last Name is mandatory.");
        else if (mobile.isEmpty())
            showToast(getActivity(), "Mobile is mandatory.");
        else if (email.isEmpty())
            showToast(getActivity(), "Email is mandatory.");
        else if (suburb.isEmpty())
            showToast(getActivity(), "Suburb is mandatory.");
        else status = true;
        return status;
    }
}