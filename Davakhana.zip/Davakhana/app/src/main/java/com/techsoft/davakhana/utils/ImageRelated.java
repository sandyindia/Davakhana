package com.techsoft.davakhana.utils;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;

import android.util.DisplayMetrics;

import androidx.fragment.app.FragmentActivity;
import androidx.loader.content.CursorLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * Created by root on 24/8/17.
 */

public class ImageRelated {

    private static int SCALE = 1;
    private static final int REQUIRED_SIZE = 100;
    public static final int REQUEST_PHOTO = 100, PICK_IMAGE_MULTIPLE = 101;

    public static Bitmap scaleImage(String path) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 3;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        while (options.outWidth / SCALE / 2 >= REQUIRED_SIZE
                && options.outHeight / SCALE / 2 >= REQUIRED_SIZE)
            SCALE *= 2;
        options.inSampleSize = SCALE;
        options.inJustDecodeBounds = false;

        return BitmapFactory.decodeFile(path, options);
    }

    /** get real path of an image from device */
    private static String getRealPathFromURI(Uri imageUri, FragmentActivity activity) {
        String[] projection = {MediaStore.MediaColumns.DATA};
        Cursor cursor = new CursorLoader(activity, imageUri, projection, null, null, null).loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();
        String selectedImagePath = cursor.getString(column_index);
        cursor.close();
        return selectedImagePath;
    }

    public static MultipartBody.Part prepareFilePart(FragmentActivity activity, String partName, Uri fileUri) {
        // use the FileUtils to get the actual file by uri
        File file = new File(getRealPathFromURI(fileUri, activity));//

        // create RequestBody instance from file
        RequestBody requestFile = RequestBody.create(MultipartBody.FORM, file);

        // MultipartBody.Part is used to send also the actual file name
        return MultipartBody.Part.createFormData(partName, file.getName(), requestFile);
    }

    public static int width(Context context, int deduction, int columns) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = (displayMetrics.widthPixels) / columns;
        return width - deduction;
    }

    public static File resizeFile(File file){
        try {

            // BitmapFactory options to downsize the image
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            o.inSampleSize = 6;
            // factor of downsizing the image

            FileInputStream inputStream = new FileInputStream(file);
            //Bitmap selectedBitmap = null;
            BitmapFactory.decodeStream(inputStream, null, o);
            inputStream.close();

            // Find the correct scale value. It should be the power of 2.
            int scale = 1;
            while(o.outWidth / scale / 2 >= REQUIRED_SIZE && o.outHeight / scale / 2 >= REQUIRED_SIZE) {
                scale *= 2;
            }

            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            inputStream = new FileInputStream(file);

            Bitmap selectedBitmap = BitmapFactory.decodeStream(inputStream, null, o2);
            inputStream.close();

            // here i override the original image file
            //file.createNewFile();
            FileOutputStream outputStream = new FileOutputStream(file);

            selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 100 , outputStream);

            return file;
        } catch (Exception e) {
            return null;
        }
    }
}