package com.techsoft.davakhana.activities;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class BaseActivity extends AppCompatActivity {

    /* add a fragment without adding it to back stack*/
    protected void addFragment(int container, Fragment fragment, String tag){
        getSupportFragmentManager()
                .beginTransaction()
                .add(container, fragment, tag)
                .commit();
    }

    protected void startAnActivity(AppCompatActivity activity, Class<?> type) {
        activity.finish();
        startActivity(new Intent(activity, type));
    }
}
