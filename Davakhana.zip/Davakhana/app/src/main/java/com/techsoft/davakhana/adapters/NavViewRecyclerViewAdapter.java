package com.techsoft.davakhana.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.techsoft.davakhana.R;
import com.techsoft.davakhana.holders.NavViewBodyHolder;
import com.techsoft.davakhana.interfaces.OnNavItemSelected;
import com.techsoft.davakhana.models.Menu;
import com.techsoft.davakhana.utils.DavakhanaSharedPreferences;

import java.util.List;

public class NavViewRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0, TYPE_ITEM = 1;

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.nav_body, parent, false);
            return new NavViewBodyHolder(v);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof NavViewBodyHolder) {
            bodyHolder = (NavViewBodyHolder) holder;
            final Menu menu = getItems(position);
            bodyHolder.tvTitle.setText(menu.getTitle());
            bodyHolder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(menu.getIcon(), 0, 0, 0);
            bodyHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.navItemSelected(menu);
                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return menus.size() + 1;
    }

    // must override to add header
    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
        return TYPE_ITEM;
    }

    private boolean isPositionHeader(int position) {
        return position == 0;
    }

    private Context context;
    private OnNavItemSelected listener;
    private List<Menu> menus = null;

    public NavViewRecyclerViewAdapter(Context context, List<Menu> menus, OnNavItemSelected listener) {
        this.context = context;
        this.listener = listener;
        this.menus = menus;
        dsp = new DavakhanaSharedPreferences(context);
    }

    private Menu getItems(int position){
        return menus.get(position - 1);
    }

    private NavViewBodyHolder bodyHolder;
    private DavakhanaSharedPreferences dsp;
}
