package com.techsoft.davakhana.utils;



import com.techsoft.davakhana.Davakhana;
import com.techsoft.davakhana.models.ApiError;

import java.io.IOException;
import java.lang.annotation.Annotation;

import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Response;

/**
 * Created by root on 25/9/17.
 */

public class ErrorUtils {

    public static ApiError parseError(Response<?> response){
        Converter<ResponseBody, ApiError> converter = Davakhana.instance()
                .api()
                .responseBodyConverter(ApiError.class, new Annotation[0]);
        ApiError apiError;
        try {
            apiError = converter.convert(response.errorBody());
        }catch (IOException e){
            return new ApiError();
        }
        return apiError;
    }
}
