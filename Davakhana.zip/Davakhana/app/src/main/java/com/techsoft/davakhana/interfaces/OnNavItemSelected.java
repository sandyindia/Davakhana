package com.techsoft.davakhana.interfaces;

import com.techsoft.davakhana.models.Menu;

public interface OnNavItemSelected {

    void navItemSelected(Menu data);
}
