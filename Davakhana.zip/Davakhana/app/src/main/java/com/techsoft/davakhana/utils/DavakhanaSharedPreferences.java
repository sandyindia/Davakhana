package com.techsoft.davakhana.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Armego on 25/8/17.
 */

public class DavakhanaSharedPreferences {

    public static final String
            PREFERENCE = DavakhanaSharedPreferences.class.getCanonicalName(),
            FCM_TOKEN = PREFERENCE + ".fcm_token",
            UID = PREFERENCE + ".uid",
            TOKEN = PREFERENCE + ".token",
            MOBILE_OR_EMAIL = PREFERENCE + ".mobile_or_email",
            REMEMBER_ME = PREFERENCE + ".remember_me";

    private SharedPreferences sharedPreferences;
    private Context context;

    public DavakhanaSharedPreferences(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREFERENCE, Context.MODE_PRIVATE);
    }

    // save a key and a value in a string
    public boolean sharePreference(String key, String value){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.apply();
        return true;
    }

    // fetch a value based on a key
    public String getPreference(String key){
        return sharedPreferences.getString(key, null);
    }

    // save a key and a value
    public boolean remeberMe(String key, boolean value){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
        return true;
    }

    // a value
    public boolean isRemembered(String key){
        return sharedPreferences.getBoolean(key, false);
    }

    public Map<String, String> getHeader(){
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Authorization", "Bearer " + getPreference(TOKEN));
        return headers;
    }

    // save a key and a value in a string
    public boolean shareIntPreference(String key, int value){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.apply();
        return true;
    }

    // fetch a value based on a key
    public int getIntPreference(String key){
        return sharedPreferences.getInt(key, 0);
    }

    public void clear() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}
