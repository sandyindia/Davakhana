package com.techsoft.davakhana.models;

import java.util.List;

/**
 * Created by User on 9/4/2017.
 */

public class ConversationPagination extends Pagination{


    private List<Conversation> data;

    public List<Conversation> getData() {
        return data;
    }

    public void setData(List<Conversation> data) {
        this.data = data;
    }
}
