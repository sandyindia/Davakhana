package com.techsoft.davakhana.fragments;


import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.gson.JsonObject;
import com.techsoft.davakhana.Davakhana;
import com.techsoft.davakhana.R;
import com.techsoft.davakhana.activities.MainActivity;
import com.techsoft.davakhana.adapters.LoginPagerAdapter;
import com.techsoft.davakhana.utils.Constant;
import com.techsoft.davakhana.utils.DavakhanaSharedPreferences;
import com.techsoft.davakhana.utils.ErrorUtils;
import com.techsoft.davakhana.widgets.GenericTextWatcher;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 */
public class LoginFragment extends BaseFragment implements View.OnClickListener, ViewPager.OnPageChangeListener, Callback<JsonObject> {


    public LoginFragment() {
        // Required empty public constructor
    }

    public static final String TAG = LoginFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        init(view);
        return view;
    }

    private String[] tags = {TAG, ForgotPasswordFragment.TAG};

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.frag_login_btn:
                if (inputsAreValid())
                    apiLogin();
                break;

            case R.id.frag_login_forgot_password:
                addFragmentToStack(getActivity(), Constant.CONTAINER_GUEST, tags, new ForgotPasswordFragment());
                break;

            case R.id.frag_login_register_with_us:
                tags [1] = RegisterWithUsFragment.TAG;
                addFragmentToStack(getActivity(), Constant.CONTAINER_GUEST, tags, new RegisterWithUsFragment());
                break;
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        FragmentActivity activity = getActivity();
        if (activity != null){
            for (int i = 0; i < dotsCount; i++) {
                dots[i].setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.dot_inactive));
            }
            dots[position].setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.dot_active));
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }


    @Override
    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
        progressBar.setVisibility(View.GONE);
        if (response.isSuccessful()){
            if (response.body().get("success").getAsBoolean())
                addToSharedPreferences(response.body());
            else showToast(getActivity(), response.body().get("message").getAsString());
        }else showToast(getActivity(), ErrorUtils.parseError(response).getMessage());
    }

    @Override
    public void onFailure(Call<JsonObject> call, Throwable t) {
        progressBar.setVisibility(View.GONE);
        call.cancel();
        showToast(getActivity(), t instanceof IOException ? Constant.NO_INTERNET_CONNECTION : Constant.UNKNOWN_ERROR);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        nsp = new DavakhanaSharedPreferences(getActivity());
    }

    @Override
    public void onPause() {
        super.onPause();
        if (apiCall != null)
            apiCall.cancel();
    }

    private void addToSharedPreferences(JsonObject body) {
        DavakhanaSharedPreferences nsp = new DavakhanaSharedPreferences(getContext());
        nsp.sharePreference(DavakhanaSharedPreferences.UID, body.get("uid").getAsString());
        nsp.sharePreference(DavakhanaSharedPreferences.TOKEN, body.get("api_token").getAsString());
        nsp.remeberMe(DavakhanaSharedPreferences.REMEMBER_ME, cbRememberMe.isChecked());
        nsp.sharePreference(DavakhanaSharedPreferences.MOBILE_OR_EMAIL, mobileOrEmail);
        startAnActivity(getActivity(), MainActivity.class);
    }

    private Call<JsonObject> apiCall = null;

    /* call login api here */
    private void apiLogin() {
        progressBar.setVisibility(View.VISIBLE);
        Map<String, String> request = new HashMap<>();
        request.put("app", Constant.APP_TYPE);
        request.put("reference_code", Constant.REFERENCE_CODE);
        request.put("mobile_or_email", mobileOrEmail);
        request.put("password", password);
        request.put("fcm_token", new DavakhanaSharedPreferences(getContext()).getPreference(DavakhanaSharedPreferences.FCM_TOKEN));
        request.put("os", Constant.OS);
        apiCall = Davakhana.instance().apiService().login(request);
        apiCall.enqueue(this);
    }

    private String mobileOrEmail = "", password = "";

    /* validate all input fields */
    private boolean inputsAreValid() {
        boolean status = false;
        if (isOnline(getActivity())){
            mobileOrEmail = nsp.getPreference(DavakhanaSharedPreferences.UID) == null
                    ? etMobileEmail.getText().toString().trim()
                    : nsp.getPreference(DavakhanaSharedPreferences.MOBILE_OR_EMAIL);
            String pin1 = etPin1.getText().toString().trim();
            String pin2 = etPin2.getText().toString().trim();
            String pin3 = etPin3.getText().toString().trim();
            String pin4 = etPin4.getText().toString().trim();
            password = pin1 + pin2 + pin3 + pin4;

            if (mobileOrEmail.isEmpty())
                showToast(getActivity(), "Mobile/Email is mandatory.");
            else if (pin1.isEmpty() || pin2.isEmpty() || pin3.isEmpty() || pin4.isEmpty())
                showToast(getActivity(), "Your four digit pin code is compulsory.");
            else status = true;
        }
        return status;
    }

    private EditText etMobileEmail, etPin1, etPin2, etPin3, etPin4;
    private CheckBox cbRememberMe;
    private ViewPager viewPager;
//    private LoginPagerAdapter loginPagerAdapter;
    private ProgressBar progressBar;
    private DavakhanaSharedPreferences nsp = null;

    /* initialize all widgets */
    private void init(View view) {
        pager_indicator = (LinearLayout) view.findViewById(R.id.view_pager_dots) ;
//        loginPagerAdapter = new LoginPagerAdapter(getChildFragmentManager());
        viewPager = (ViewPager) view.findViewById(R.id.view_pager);
//        viewPager.setAdapter(loginPagerAdapter);
        //viewPager.setCurrentItem(0);
        viewPager.addOnPageChangeListener(this);
        runSlide();
        setUiPageViewController();

        etMobileEmail = (EditText) view.findViewById(R.id.mob_or_mail);

        etPin1 = (EditText) view.findViewById(R.id.et_pin_1);
        etPin2 = (EditText) view.findViewById(R.id.et_pin_2);
        etPin3 = (EditText) view.findViewById(R.id.et_pin_3);
        etPin4 = (EditText) view.findViewById(R.id.et_pin_4);
        cbRememberMe = (CheckBox) view.findViewById(R.id.frag_login_remember_me);

        /* set on click listeners */
        view.findViewById(R.id.frag_login_btn).setOnClickListener(this);
        TextView tvForgotPassCode = (TextView) view.findViewById(R.id.frag_login_forgot_password);
        Typeface typeface = font(getActivity(), "handmade.otf");
        tvForgotPassCode.setTypeface(typeface);
        tvForgotPassCode.setOnClickListener(this);

       // TextView tvOr = (TextView) view.findViewById(R.id.frag_login_or);
        TextView tvRegister = (TextView) view.findViewById(R.id.frag_login_register_with_us);

        // if uid exists in shared preferences let the normal flow be
        if (nsp.getPreference(DavakhanaSharedPreferences.UID) == null) {
          //  tvOr.setTypeface(typeface);
            tvRegister.setTypeface(typeface);
            tvRegister.setOnClickListener(this);
        }
        else { // otherwise hide unwanted views
            etMobileEmail.setVisibility(View.GONE);
         //   view.findViewById(R.id.frag_login_or).setVisibility(View.GONE);
            tvRegister.setVisibility(View.GONE);
        }

        view.findViewById(R.id.image_view_logo).setAnimation(animate(getActivity(), R.anim.anim_image_middle_to_top_with_scaling_login));
        view.findViewById(R.id.frag_login_slide_ll).setAnimation(animate(getActivity(), R.anim.right_to_left));
        view.findViewById(R.id.frag_login_auth_ll).setAnimation(animate(getActivity(), R.anim.left_to_right));

        etPin1.addTextChangedListener(new GenericTextWatcher(etPin2));
        etPin2.addTextChangedListener(new GenericTextWatcher(etPin3));
        etPin3.addTextChangedListener(new GenericTextWatcher(etPin4));

        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_circular);
    }

    private int dotsCount = 0;
    private ImageView[] dots;
    private LinearLayout pager_indicator;

    private void setUiPageViewController() {

//        dotsCount = loginPagerAdapter.getCount();
        dots = new ImageView[dotsCount];

        for (int i = 0; i < dotsCount; i++) {
            dots[i] = new ImageView(getActivity());
            dots[i].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.dot_inactive));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );

            params.setMargins(4, 0, 4, 0);

            pager_indicator.addView(dots[i], params);
        }

        dots[0].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.dot_active));
    }

    private Handler handler = null;
    private Runnable runnable;
    private int currentPage = 0;

    private void runSlide(){
        runnable = new Runnable() {
            @Override
            public void run() {
                if (currentPage == dotsCount )
                    currentPage = 0;
                viewPager.setCurrentItem(currentPage++, true);
            }
        };
        handler = new Handler();
        new Timer().schedule(new TimerTask() {

            @Override
            public void run() {
                handler.post(runnable);
            }
        },300, 3000);
    }
}
