package com.techsoft.davakhana.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.JsonObject;

import com.techsoft.davakhana.Davakhana;
import com.techsoft.davakhana.widgets.GenericTextWatcher;
import com.techsoft.davakhana.R;
import com.techsoft.davakhana.utils.Constant;
import com.techsoft.davakhana.utils.ErrorUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 */
public class PasswordResetFragment extends BaseFragment implements View.OnClickListener, Callback<JsonObject> {


    public PasswordResetFragment() {
        // Required empty public constructor
    }

    public static final String TAG = PasswordResetFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_password_reset, container, false);
        init(view);
        return view;
    }

    @Override
    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
        progressBar.setVisibility(View.GONE);
        if (response.isSuccessful()) {
            showToast(getActivity(), response.body().get("message").getAsString());
            if (response.body().get("success").getAsBoolean())
                gotoNextFragment();
        }else showToast(getActivity(), ErrorUtils.parseError(response).getMessage());
    }

    @Override
    public void onFailure(Call<JsonObject> call, Throwable t) {
        progressBar.setVisibility(View.GONE);
        call.cancel();
        showToast(getActivity(), t instanceof IOException ? Constant.NO_INTERNET_CONNECTION : Constant.UNKNOWN_ERROR);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.tv_btn_end:
                if (inputsAreValid())
                    apiResetPassCode();
                break;
        }
    }

    private String password = "";

    /* validate all input fields */
    private boolean inputsAreValid() {
        boolean status = false;
        String pin1 = etPin1.getText().toString().trim();
        String pin2 = etPin2.getText().toString().trim();
        String pin3 = etPin3.getText().toString().trim();
        String pin4 = etPin4.getText().toString().trim();

        String confirmPin1 = etConfirmPin1.getText().toString().trim();
        String confirmPin2 = etConfirmPin2.getText().toString().trim();
        String confirmPin3 = etConfirmPin3.getText().toString().trim();
        String confirmPin4 = etConfirmPin4.getText().toString().trim();

        password = pin1 + pin2 + pin3 + pin3;

        if (pin1.isEmpty() || pin2.isEmpty() || pin3.isEmpty() || pin4.isEmpty())
            showToast(getActivity(), "Your four digit pin code is compulsory.");
        else if (confirmPin1.isEmpty() || confirmPin2.isEmpty() || confirmPin3.isEmpty()
                || confirmPin4.isEmpty())
            showToast(getActivity(), "Your must confirm four digit pin.");
        else if (!password.equals(confirmPin1 + confirmPin2 + confirmPin3 + confirmPin4))
            showToast(getActivity(), "Your four digit pins do not match.");
        else status = true;
        return status;
    }

    private EditText etPin1, etPin2, etPin3, etPin4, etConfirmPin1, etConfirmPin2,
            etConfirmPin3, etConfirmPin4;


    private Bundle bundle = null;
    private ProgressBar progressBar;

    private void init(View view) {
        TextView tvTitle = (TextView) view.findViewById(R.id.frag_password_reset_title);

        bundle = getArguments();
        if (bundle != null) {
            String title = "Reset pin code for " + bundle.getString(Constant.BUNDLE_MOBILE_OR_EMAIL);
            tvTitle.setText(title);

            etPin1 = (EditText) view.findViewById(R.id.et_pin_1);
            etPin2 = (EditText) view.findViewById(R.id.et_pin_2);
            etPin3 = (EditText) view.findViewById(R.id.et_pin_3);
            etPin4 = (EditText) view.findViewById(R.id.et_pin_4);

            etConfirmPin1 = (EditText) view.findViewById(R.id.et_pin_cp_1);
            etConfirmPin2 = (EditText) view.findViewById(R.id.et_pin_cp_2);
            etConfirmPin3 = (EditText) view.findViewById(R.id.et_pin_cp_3);
            etConfirmPin4 = (EditText) view.findViewById(R.id.et_pin_cp_4);

            view.findViewById(R.id.tv_btn_end).setOnClickListener(this);

            etPin1.addTextChangedListener(new GenericTextWatcher(etPin2));
            etPin2.addTextChangedListener(new GenericTextWatcher(etPin3));
            etPin3.addTextChangedListener(new GenericTextWatcher(etPin4));

            etConfirmPin1.addTextChangedListener(new GenericTextWatcher(etConfirmPin2));
            etConfirmPin2.addTextChangedListener(new GenericTextWatcher(etConfirmPin3));
            etConfirmPin3.addTextChangedListener(new GenericTextWatcher(etConfirmPin4));
            progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_circular);
        }
    }

    private Call<JsonObject> apiCall = null;

    /* call login api here */
    private void apiResetPassCode() {
        if (isOnline(getActivity())){
            progressBar.setVisibility(View.VISIBLE);
            Map<String, String> request = new HashMap<>();
            request.put("app", Constant.APP_TYPE);
            request.put("reference_code", Constant.REFERENCE_CODE);
            request.put("mobile_or_email", bundle.getString(Constant.BUNDLE_MOBILE_OR_EMAIL));
            request.put("password", password);
            apiCall = Davakhana.instance().apiService().resetPasswordGuest(request);
            apiCall.enqueue(this);
        }
    }

    private void gotoNextFragment() {
        replaceFragment(getActivity(), Constant.CONTAINER_GUEST, new LoginFragment());
    }

    @Override
    public void onPause() {
        super.onPause();
        if (apiCall != null)
            apiCall.cancel();
    }
}
