package com.techsoft.davakhana.holders;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.techsoft.davakhana.R;

public class NavViewBodyHolder extends RecyclerView.ViewHolder  {

    public View itemView;
    public TextView tvTitle,tvCount;

    public NavViewBodyHolder(View view){
        super(view);
        itemView = view;
        tvTitle = (TextView) itemView.findViewById(R.id.nav_body_left);
    }
}
