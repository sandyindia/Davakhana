package com.techsoft.davakhana.interfaces;

import com.google.gson.JsonObject;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.HeaderMap;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;

/**
 * Created by root on 23/8/17.
 */

public interface ApiService {

    @Headers("Content-Type: application/json")
    @POST("login")
    Call<JsonObject> login(@Body Map<String, String> body);

    @Headers("Content-Type: application/json")
    @POST("forgot-password")
    Call<JsonObject> forgotPassword(@Body Map<String, String> body);

    @Headers("Content-Type: application/json")
    @POST("password-reset-guest")
    Call<JsonObject> resetPasswordGuest(@Body Map<String, String> body);

    @Headers("Content-Type: application/json")
    @POST("otp")
    Call<JsonObject> otp(@Body Map<String, String> body);

    @Multipart
    @POST("register")
    Call<JsonObject> register(@PartMap() Map<String, RequestBody> partMap, @Part MultipartBody.Part file);

    @POST("user/home")
    Call<JsonObject> home(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("offer-services")
    Call<JsonObject> offersAndServices(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("booking-list")
    Call<JsonObject> bookings(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("booking")
    Call<JsonObject> createBooking(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("booking-status")
    Call<JsonObject> changeBookingStatus(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("invoice-list")
    Call<JsonObject> invoices(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("offer-list")
    Call<JsonObject> offers(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("client-blog")
    Call<JsonObject> blogs(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("blog-detail")
    Call<JsonObject> blogDetail(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("blog-comment")
    Call<JsonObject> addBlogComment(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("blog-like-unlike")
    Call<JsonObject> favBlog(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("complaints")
    Call<JsonObject> complaints(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("complaint-details")
    Call<JsonObject> complaintDetails(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("complaint-reply")
    Call<JsonObject> replyTicketComment(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("complaint-status")
    Call<JsonObject> ticketStatus(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("review/client")
    Call<JsonObject> reviews(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @Multipart
    @POST("profile-update")
    Call<JsonObject> updateProfile(@HeaderMap Map<String, String> header, @PartMap() Map<String,
            RequestBody> partMap, @Part MultipartBody.Part file);

    @POST("password-reset")
    Call<JsonObject> resetPassword(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @Multipart
    @POST("complain")
    Call<JsonObject> complain(@HeaderMap Map<String, String> header, @PartMap() Map<String,
            RequestBody> partMap, @Part MultipartBody.Part[] files);

    @POST("review")
    Call<JsonObject> writeReview(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("conversation-recent")
    Call<JsonObject> recentConversation(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    //@POST("conversation")
   // Call<ConversationPagination> conversations(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("notification")
    Call<JsonObject> sendMessage(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("contact")
    Call<JsonObject> contact(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

    @POST("make-payment")
    Call<JsonObject> makePayment(@HeaderMap Map<String, String> header, @Body Map<String, String> body);

}
